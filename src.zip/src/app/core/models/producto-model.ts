export class ProductoModel {
    id!: number;
    nombre!: string;
    precio!: number;
    imagen!: string;
    descripcion!: string;
    tipo!: string;
}

